<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-xl text-slate-800 leading-tight">
            {{ __('Dashboard Piket & Absensi') }}
        </h2>
    </x-slot>

    <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
        
        @if (session('success'))
            <div class="mb-4 bg-emerald-50 text-emerald-700 px-4 py-3 rounded-2xl flex items-center gap-2">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor"><path fill-rule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clip-rule="evenodd" /></svg>
                {{ session('success') }}
            </div>
        @endif

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div class="bg-white border border-slate-100 shadow-sm rounded-2xl p-6">
                <h3 class="text-lg font-semibold text-slate-800 mb-4 border-b border-slate-100 pb-2">Informasi Jadwal Hari Ini</h3>
                
                @if($schedule)
                    <div class="space-y-3">
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Kelompok:</span>
                            <span class="font-medium text-slate-900">{{ $schedule->team->name }}</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Shift Kerja:</span>
                            <span class="font-medium text-slate-900">{{ $schedule->shift->name }}</span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Waktu:</span>
                            <span class="font-medium text-sky-600 bg-sky-50 px-3 py-1 rounded-full text-sm">
                                {{ \Carbon\Carbon::parse($schedule->shift->start_time)->format('H:i') }} - {{ \Carbon\Carbon::parse($schedule->shift->end_time)->format('H:i') }} WIB
                            </span>
                        </div>
                        <div class="flex justify-between items-center">
                            <span class="text-slate-500">Lokasi:</span>
                            <span class="font-medium uppercase tracking-wide {{ $schedule->shift->location === 'mncu' ? 'text-sky-700 bg-sky-50' : 'text-purple-700 bg-purple-50' }} px-3 py-1 rounded-full text-sm">
                                {{ $schedule->shift->location }}
                            </span>
                        </div>
                    </div>
                @else
                    <div class="text-center py-6 text-slate-500">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 mx-auto text-slate-300 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                        </svg>
                        <p>Anda tidak memiliki jadwal piket untuk hari ini.</p>
                    </div>
                @endif
            </div>

            <div class="bg-white border border-slate-100 shadow-sm rounded-2xl p-6 flex flex-col justify-center items-center text-center">
                @if(!$schedule)
                    <p class="text-slate-500">Absensi tidak tersedia. Silakan hubungi Sekretaris jika ada kesalahan jadwal.</p>
                @else
                    @if(!$absence)
                        <div class="mb-4 text-slate-600">Silakan lakukan Check-In untuk memulai shift Anda.</div>
                        <form action="{{ route('staff.checkin') }}" method="POST">
                            @csrf
                            <input type="hidden" name="picket_schedule_id" value="{{ $schedule->id }}">
                            <button type="submit" class="bg-sky-500 hover:bg-sky-600 text-white font-semibold px-8 py-4 rounded-2xl shadow-sm transition transform active:scale-95 text-lg w-full md:w-auto">
                                Check-In Sekarang
                            </button>
                        </form>
                    @elseif($absence && !$absence->check_out_time)
                        <div class="mb-2 text-emerald-600 font-medium bg-emerald-50 px-4 py-2 rounded-2xl inline-block">
                            Status: Sedang Bertugas
                        </div>
                        <p class="text-slate-500 mb-6">Waktu Check-In: <span class="font-semibold text-slate-800">{{ \Carbon\Carbon::parse($absence->check_in_time)->format('H:i') }} WIB</span></p>
                        
                        <form action="{{ route('staff.checkout', $absence->id) }}" method="POST">
                            @csrf
                            @method('PUT')
                            <button type="submit" onclick="return confirm('Apakah Anda yakin shift sudah selesai dan ingin Check-Out?')" class="bg-rose-500 hover:bg-rose-600 text-white font-semibold px-8 py-4 rounded-2xl shadow-sm transition transform active:scale-95 text-lg w-full md:w-auto">
                                Check-Out (Selesai Shift)
                            </button>
                        </form>
                    @else
                        <div class="text-slate-800">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-16 w-16 mx-auto text-emerald-500 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                            </svg>
                            <h3 class="text-xl font-semibold mb-2">Shift Selesai!</h3>
                            <p class="text-slate-500">Terima kasih atas kerja keras Anda hari ini.</p>
                            <div class="mt-4 text-sm text-slate-600">
                                Check-In: {{ \Carbon\Carbon::parse($absence->check_in_time)->format('H:i') }} WIB<br>
                                Check-Out: {{ \Carbon\Carbon::parse($absence->check_out_time)->format('H:i') }} WIB
                            </div>
                        </div>
                    @endif
                @endif
            </div>
        </div>
    </div>
</x-app-layout>