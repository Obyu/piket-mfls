<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PicketSchedule extends Model
{
    protected $fillable = ['date', 'shift_id', 'team_id'];

    public function shift()
    {
        return $this->belongsTo(Shift::class);
    }

    public function team()
    {
        return $this->belongsTo(Team::class);
    }

    public function absences()
    {
        return $this->hasMany(Absence::class);
    }

    public function notifications()
    {
        return $this->hasMany(Notification::class);
    }

    public function reports()
    {
        return $this->hasMany(Report::class);
    }
}