<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\PicketSchedule;
use App\Models\Shift;
use App\Models\Team;
use Illuminate\Http\Request;

class PicketScheduleController extends Controller
{
    // Menampilkan halaman jadwal dengan data shift dan tim untuk dropdown
    public function index()
    {
        // Mengambil jadwal beserta relasinya
        $schedules = PicketSchedule::with(['shift', 'team'])->orderBy('date', 'desc')->get();
        $shifts = Shift::all();
        $teams = Team::all();

        return view('admin.schedules.index', compact('schedules', 'shifts', 'teams'));
    }

    // Menyimpan jadwal baru
    public function store(Request $request)
    {
        $request->validate([
            'date' => 'required|date',
            'shift_id' => 'required|exists:shifts,id',
            'team_id' => 'required|exists:teams,id',
        ]);

        // Cek agar tidak ada jadwal bentrok untuk tim yang sama di shift dan hari yang sama
        $exists = PicketSchedule::where('date', $request->date)
                    ->where('shift_id', $request->shift_id)
                    ->where('team_id', $request->team_id)
                    ->exists();

        if ($exists) {
            return back()->withErrors(['message' => 'Jadwal untuk tim ini pada shift tersebut sudah ada.']);
        }

        PicketSchedule::create($request->all());

        return redirect()->route('admin.schedules.index')->with('success', 'Jadwal berhasil ditambahkan.');
    }

    public function destroy(PicketSchedule $schedule)
    {
        $schedule->delete();
        return redirect()->route('admin.schedules.index')->with('success', 'Jadwal berhasil dihapus.');
    }
}