<?php

namespace App\Http\Controllers\Staff;

use App\Http\Controllers\Controller;
use App\Models\Absence;
use App\Models\PicketSchedule;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class AbsenceController extends Controller
{
    // Halaman Dashboard Staff
    public function index()
    {
        $user = Auth::user();
        $today = Carbon::today()->toDateString();

        // Mencari jadwal piket user hari ini berdasarkan tim-nya
        $schedule = PicketSchedule::where('team_id', $user->team_id)
                        ->where('date', $today)
                        ->first();

        $absence = null;
        if ($schedule) {
            // Cek apakah user sudah absen hari ini
            $absence = Absence::where('user_id', $user->id)
                        ->where('picket_schedule_id', $schedule->id)
                        ->first();
        }

        return view('staff.dashboard', compact('schedule', 'absence'));
    }

    // Proses Check-In
    public function checkIn(Request $request)
    {
        $request->validate(['picket_schedule_id' => 'required|exists:picket_schedules,id']);

        Absence::create([
            'picket_schedule_id' => $request->picket_schedule_id,
            'user_id' => Auth::id(),
            'check_in_time' => Carbon::now(),
        ]);

        return back()->with('success', 'Berhasil Check-In.');
    }

    // Proses Check-Out
    public function checkOut(Request $request, Absence $absence)
    {
        // Pastikan absensi milik user yang sedang login
        if ($absence->user_id !== Auth::id()) {
            abort(403);
        }

        $absence->update([
            'check_out_time' => Carbon::now(),
        ]);

        return back()->with('success', 'Berhasil Check-Out.');
    }
}